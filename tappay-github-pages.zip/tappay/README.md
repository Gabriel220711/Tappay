# TapPay — versão inicial

## O que é
Um protótipo estático para criar páginas individuais de pagamento Pix e gravar o endereço em uma tag NFC.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub chamado `tappay`.
2. Envie `index.html` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione `main` e `/ (root)` e salve.
6. Aguarde a publicação e abra o endereço informado pelo GitHub.

## Como cadastrar uma loja
1. Abra a página principal do TapPay.
2. Preencha nome da loja, cidade e chave Pix pública de recebimento.
3. Clique em **Gerar página da loja** e copie o endereço individual.
4. Grave esse endereço na tag NFC pelo NFC Tools: Escrever → Adicionar um registro → URL/URI.

## Limitações importantes
- Esta versão monta um Pix estático com valor preenchido pelo pagador.
- Não há confirmação automática, conciliação, notificações nem consulta de pagamento.
- A chave Pix fica codificada no endereço público da loja. Ela não é uma senha, mas deve ser tratada como dado de recebimento e usada com autorização do titular.
- O QR Code é carregado por um serviço externo de geração de imagem.
- Antes de uso comercial, valide o BR Code com o banco/provedor e faça testes pequenos. Confira sempre nome do recebedor e valor no app bancário.
- Para confirmação automática ou cobranças dinâmicas, será necessário um provedor Pix com API e um backend seguro. GitHub Pages sozinho não pode guardar segredos de API nem receber webhooks.
